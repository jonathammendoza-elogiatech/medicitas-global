---
name: Vibrant Clinical Care
colors:
  surface: '#f7f9fd'
  surface-dim: '#d8dade'
  surface-bright: '#f7f9fd'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f8'
  surface-container: '#eceef2'
  surface-container-high: '#e6e8ec'
  surface-container-highest: '#e0e3e6'
  on-surface: '#181c1f'
  on-surface-variant: '#424654'
  inverse-surface: '#2d3134'
  inverse-on-surface: '#eff1f5'
  outline: '#727786'
  outline-variant: '#c2c6d7'
  surface-tint: '#0058ca'
  primary: '#004cb0'
  on-primary: '#ffffff'
  primary-container: '#0263e0'
  on-primary-container: '#e5eaff'
  inverse-primary: '#b0c6ff'
  secondary: '#00677d'
  on-secondary: '#ffffff'
  secondary-container: '#50d9fe'
  on-secondary-container: '#005c70'
  tertiary: '#005e3f'
  on-tertiary: '#ffffff'
  tertiary-container: '#007953'
  on-tertiary-container: '#9affcd'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d9e2ff'
  primary-fixed-dim: '#b0c6ff'
  on-primary-fixed: '#001944'
  on-primary-fixed-variant: '#00429a'
  secondary-fixed: '#b3ebff'
  secondary-fixed-dim: '#4cd6fb'
  on-secondary-fixed: '#001f27'
  on-secondary-fixed-variant: '#004e5f'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#f7f9fd'
  on-background: '#181c1f'
  surface-variant: '#e0e3e6'
  status-attended: '#10b981'
  status-attended-container: '#d1fae5'
  status-attended-text: '#047857'
  status-pending: '#f59e0b'
  status-pending-container: '#fef3c7'
  status-pending-text: '#b45309'
  status-alert: '#ef4444'
  status-alert-container: '#fee2e2'
  status-alert-text: '#b91c1c'
  status-scheduled: '#0263e0'
  status-scheduled-container: '#e8f1fd'
  status-scheduled-text: '#024bb0'
  surface-card: '#ffffff'
  text-primary: '#0f172a'
  text-secondary: '#475569'
  text-tertiary: '#94a3b8'
  border-subtle: '#e2e8f0'
typography:
  headline-lg:
    fontFamily: Manrope
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Manrope
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Manrope
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Manrope
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
  data-metric-lg:
    fontFamily: Manrope
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.02em
  data-metric-md:
    fontFamily: Manrope
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 26px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-mobile: 0.75rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.25rem
---

## Brand & Style

This design system establishes an ultra-modern, luminous, and emotionally reassuring clinical interface created for assisted reproduction, fertility specialists, and prospective families. It moves decisively away from traditional, sterile petrol-blue institutional aesthetics into a vibrant, tech-forward, and empathetic digital environment.

### Personality & Core Attributes
- **Luminous & Optimistic:** Inspires trust, vitality, and clinical hope through bright atmospheric light and clean airy surfaces.
- **Technologically Advanced:** Balances medical rigor and cutting-edge biotechnology with crisp typography, systematic elevation, and high-fidelity micro-interactions.
- **Empathetic & Human-Centric:** Warm, accessible, and respectful of sensitive patient experiences without becoming casual or frivolous.

### Design Movement & Influence
The design system fuses **Material Design 3 Contemporary** with high-end digital health minimalism:
- **Surface Elevation:** Translucent atmospheric tints, low-strain borders, and elevated soft tonal containers instead of aggressive drop shadows.
- **Visual Rhythm:** Generous breathable negative space, precise tabular data structures for lab metrics (beta-hCG, follicular scans, embryology records), and organic pill badges for clinical states.

## Colors

The color system delivers high visual clarity, emotional freshness, and strict contrast ratios (WCAG AAA for typography, minimum 4.5:1 for interactive states).

### Roles & Semantic Distribution
- **Primary (`#0263E0` - Electric Cerulean):** Expresses technical precision, confidence, and reliability. Applied to dominant actions, navigation focal points, active state indicators, and primary data highlights.
- **Secondary (`#00B4D8` - Luminous Cyan):** Evokes vitality, clarity, and biological discovery. Used for secondary active buttons, interactive iconography, subtle gradients, and progress graphs.
- **Tertiary (`#10B981` - Emerald Mint):** Represents health, successful diagnostic thresholds, normal ranges, and positive outcomes.
- **Neutral Surface Palette (`#F6F8FC` to `#FFFFFF`):** High-luminance, anti-glare clean canvas with cool blue-slate undertones designed to reduce eye strain in clinical operating rooms and bright consultation suites.

### Status Tonal Tokens
- **Confirmed / In Progress:** `#0263E0` (Cerulean) on `#E8F1FD` container.
- **Attended / Optimal Range:** `#10B981` (Mint) on `#D1FAE5` container.
- **Pending / In Observation:** `#F59E0B` (Warm Amber) on `#FEF3C7` container.
- **Out of Range / Critical:** `#EF4444` (Coral Red) on `#FEE2E2` container.

## Typography

The pairing blends the clean structural balance of **Manrope** for authoritative clinical headlines and numerical diagnostic data with the welcoming, rounded clarity of **Plus Jakarta Sans** for body copy, instructions, and user navigation.

- **Tabular Lining:** All metric figures (`data-metric-lg`, `data-metric-md`) and laboratory tables enforce tabular numbers (`font-feature-settings: "tnum" 1`) to guarantee aligned decimal points across longitudinal treatment records.
- **Readability & Density:** Body text leverages generous line heights (1.5x) to maintain effortless scannability of medical notes, prescription regimens, and patient clinical histories.

## Layout & Spacing

The layout is built on a responsive 12-column grid for desktop/tablet clinical dashboards, adapting to a 4-column fluid system on mobile viewports.

- **Mobile Viewport (up to 600px):** 4-column grid with 16px (`margin-mobile`) outer borders and 12px (`gutter-mobile`) column spacing. All interactive touch targets must meet a strict minimum size of 48×48px.
- **Tablet & Desktop Viewport (600px+ to 1440px):** 12-column grid with 32px (`margin`) margins and 16px (`gutter`) gutters, presenting modular bento cards that separate calendar schedules, patient summaries, and real-time laboratory indicators.
- **Vertical Spacing Rhythm:** Micro elements within cards align to `space-xs` (4px) and `space-sm` (8px), while layout containers and sections step through `space-md` (16px), `space-lg` (24px), and `space-xl` (36px).

## Elevation & Depth

Depth is established via subtle chromatic blurs, luminous tonal layers, and hairline borders rather than heavy, muddy shadows.

- **Level 0 (Base Canvas):** Light atmospheric wash (`#F6F8FC`).
- **Level 1 (Clinical Cards & Summary Modules):** Pure white surface (`#FFFFFF`) framed with a subtle border (`1px solid #E2E8F0`) and a soft ambient shadow: `0 2px 8px -2px rgba(2, 99, 224, 0.04), 0 1px 2px rgba(15, 23, 42, 0.03)`.
- **Level 2 (Hovered Cards & Interactive Controls):** Elevated with a vibrant, low-opacity glow: `0 8px 24px -4px rgba(2, 99, 224, 0.08), 0 2px 6px rgba(15, 23, 42, 0.04)`.
- **Level 3 (Modals, Slide-overs & Sticky Navigation Bars):** Frosted glass effect with `backdrop-filter: blur(12px)`, background `rgba(255, 255, 255, 0.88)`, border `1px solid rgba(226, 232, 240, 0.8)`, and a diffuse drop shadow `0 16px 36px -8px rgba(15, 23, 42, 0.1)`.

## Shapes

The design uses balanced rounded geometry (`roundedness: 2` / 8px base) that strikes an optimal equilibrium between approachable warmth and technical precision.

- **Base Components (Inputs, Buttons):** Standard radius of 10px to 12px (`rounded-md`), communicating immediate tactility and affordance.
- **Content Cards & Panels:** Radius of 16px (`rounded-lg`) up to 24px (`rounded-xl`), creating distinct, friendly modules that soften clinical tension.
- **Pills & Tags:** 9999px (`full`), reserved for laboratory range markers, status badges, patient tags, and segmented control indicators.

## Components

### Buttons
- **Primary:** Background `#0263E0`, text `#FFFFFF`, font `label-lg`, height 48px, radius 12px, subtle shadow `0 4px 14px rgba(2, 99, 224, 0.25)`. Hover: `#0256C4`. Pressed: `#024BB0`.
- **Secondary (Luminous Tint):** Background `#E8F1FD`, text `#0263E0`, height 48px, radius 12px. Hover: `#D8E7FB`.
- **Tertiary / Outlined:** Background transparent, border `1.5px solid #E2E8F0`, text `#0F172A`, radius 12px. Hover: background `#F8FAFC`, border `#CBD5E1`.

### Inputs & Form Fields
- **Container:** Minimum height 52px, background `#FFFFFF`, border `1px solid #E2E8F0`, radius 10px, padding 12px 16px.
- **Active / Focus:** Border `2px solid #0263E0`, box-shadow `0 0 0 4px rgba(2, 99, 224, 0.12)`.
- **Labels:** Floating or top label rendered in `label-md` `#475569`.

### Chips & Filter Pills
- Height 32px, radius 9999px, padding 0 14px.
- **Selected:** Background `#0263E0`, text `#FFFFFF`, font `label-md`.
- **Unselected:** Background `#FFFFFF`, border `1px solid #E2E8F0`, text `#475569`.

### Status Badges
- Height 26px, padding 4px 10px, radius 9999px, font `label-sm`. Contains a 6px solid circular status indicator:
  - *Confirmado / Activo:* Background `#E8F1FD`, text `#024BB0`, dot `#0263E0`.
  - *Atendido / En Rango:* Background `#D1FAE5`, text `#047857`, dot `#10B981`.
  - *Reprogramado / Pendiente:* Background `#FEF3C7`, text `#B45309`, dot `#F59E0B`.
  - *Cancelado / Fuera de Rango:* Background `#FEE2E2`, text `#B91C1C`, dot `#EF4444`.

### Patient & Clinical Cards
- Background `#FFFFFF`, border `1px solid #E2E8F0`, radius 16px, padding 20px, subtle shadow Level 1.
- Includes quick-access patient biometric initials badge in soft `#E8F1FD` with `#0263E0` text, distinct diagnosis tag, and responsive treatment cycle indicators.

### Diagnostic & Metric Strips
- Dedicated modular container highlighting biomarker counts (e.g., Folículos Antrales, Beta-hCG, E2).
- Features bold data in `data-metric-lg` `#0F172A`, baseline metric unit in `label-md` `#94A3B8`, and inline health validation chip in `#10B981`.

### Bottom Navigation Bar (Mobile) & Clinical Sidebar (Desktop)
- **Mobile Bottom Bar:** Height 68px + safe area padding, frosted glass `#FFFFFF` with `backdrop-filter: blur(16px)`, border-top `1px solid #E2E8F0`.
  - Active item features an animated pill indicator `#E8F1FD` holding icon and text in vibrant `#0263E0`.
  - Inactive items rendered in `#94A3B8`.