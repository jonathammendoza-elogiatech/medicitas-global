---
name: Clinical Care
colors:
  surface: '#f8f9ff'
  surface-dim: '#d1dbea'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eef4ff'
  surface-container: '#e4effe'
  surface-container-high: '#dfe9f8'
  surface-container-highest: '#d9e3f3'
  on-surface: '#121c27'
  on-surface-variant: '#41484c'
  inverse-surface: '#27313d'
  inverse-on-surface: '#e9f1ff'
  outline: '#71787d'
  outline-variant: '#c1c7cc'
  surface-tint: '#366479'
  primary: '#002e3e'
  on-primary: '#ffffff'
  primary-container: '#124559'
  on-primary-container: '#85b2c9'
  inverse-primary: '#a0cde5'
  secondary: '#006a65'
  on-secondary: '#ffffff'
  secondary-container: '#8df1e8'
  on-secondary-container: '#006f69'
  tertiary: '#00311f'
  on-tertiary: '#ffffff'
  tertiary-container: '#004a31'
  on-tertiary-container: '#6ebb95'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#bfe8ff'
  primary-fixed-dim: '#a0cde5'
  on-primary-fixed: '#001f2b'
  on-primary-fixed-variant: '#1b4c60'
  secondary-fixed: '#90f3eb'
  secondary-fixed-dim: '#73d7cf'
  on-secondary-fixed: '#00201e'
  on-secondary-fixed-variant: '#00504c'
  tertiary-fixed: '#a4f3ca'
  tertiary-fixed-dim: '#88d6af'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#f8f9ff'
  on-background: '#121c27'
  surface-variant: '#d9e3f3'
typography:
  headline-lg:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  title-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.05em
  data-metric-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 28px
  data-metric-md:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 22px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 0.75rem
  margin: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style

This design system establishes an authoritative, highly dependable, and sober clinical interface engineered for specialists in assisted reproduction and reproductive medicine. Designed specifically for specialized mobile workflows, the visual language avoids decorative distractions, unnecessary illustrations, or colloquial metaphors, grounding itself strictly in clinical rigor, precision, and patient privacy.

The aesthetic adapts Material Design 3 into a technical, high-density medical context:
- **Tone:** Professional, precise, tranquil, scientific, and uncompromised in data legibilidad.
- **Visual Style:** Adapted Material 3 with structural borders, deliberate contrast, and functional surface layers rather than heavy drop shadows.
- **Form Factor Focus:** Mobile-first clinical handheld devices used during outpatient consultations, ultrasound diagnostics, and surgical scheduling.

## Colors

The palette is engineered to maximize contrast in sterile or variable lighting conditions. Structural and semantic tokens map directly to clinical indicators and appointment workflows.

### Core Tonal Foundations
- **Primary (`#124559` - Petrol Blue):** Main navigation anchors, primary action buttons, active tab indicators, and confirmed appointments.
- **Primary Pressed (`#0B2C39`):** Explicit active/pressed state for primary touchpoints.
- **Accent Support (`#3FA7A0` - Clinical Turquoise):** Focused highlights, selected filter chips, secondary toggles, and contextual badge indicators.
- **Background (`#F4F7F9`):** Neutral cool foundation preventing glare while separating pure white containers.
- **Surface & Cards (`#FFFFFF`):** Base canvas for clinical summaries, diagnostic cards, and modular sheets.
- **Text High-Emphasis (`#16202B`):** Medical record IDs, diagnostic metrics, patient names, and primary data labels (minimum contrast ratio > 11:1).
- **Text Medium-Emphasis (`#4A5563`):** Descriptive subtitles, timestamp labels, unit tags, and field titles.
- **Borders & Dividers (`#E3E8EE`):** Low-strain boundaries for container definition without visual noise.

### Clinical Semantics & Appointments
Status tokens communicate state instantly through dual encoding (color and text label):
- **Confirmed / Por Confirmar:** `#124559` (Petrol Blue)
- **Attended / Within Range:** `#2E7D5B` (Sober Clinical Green)
- **Rescheduled / Pending:** `#C98A0E` (Clinical Amber)
- **Cancelled / Out of Range:** `#B3261E` (Diagnostic Alert Red)

## Typography

Typography prioritizes tabular clarity and rapid skimming. **Inter** is chosen for its neutral legibility, tall x-height, and robust OpenType tabular lining figures (`tnum`), essential for comparing beta-hCG curves, follicle diameters, endometrial thickness, and sperm motility values.

- **Tabular Numerics:** All medical metrics and laboratory tables must enable `font-feature-settings: "tnum" 1` to ensure vertical alignment of digits.
- **Labels:** Uppercase styling is reserved strictly for `label-sm` when indicating clinical categories or critical specimen identifiers.
- **Hierarchical Balance:** Headings are restrained, never exceeding 28px on mobile viewports to preserve screen estate for actionable patient records.

## Layout & Spacing

The layout is built on a 4-column mobile fluid grid with standard 16px (`1rem`) outer margins and 12px (`0.75rem`) gutters. 

- **Touch Surface Guarantees:** Every actionable touchpoint adheres to the strict 48×48dp minimum physical target box, regardless of visible glyph or chip size.
- **Density Controls:** Information is clustered by diagnostic domain (e.g., patient identity header, active hormonal treatment block, scheduling log) using `space-sm` (8px) for inner-card elements and `space-lg` (16px) between structural sections.
- **Safe Area Insets:** Account explicitly for native top dynamic islands/notches and bottom indicator bars, ensuring the 4-destination navigation bar anchors safely above the native system gesture handle.

## Elevation & Depth

Visual separation relies on crisp border definition and tonal layering rather than high-elevation shadows:

- **Surface Level 0 (Canvas):** Base mobile canvas rendered at `#F4F7F9`.
- **Surface Level 1 (Clinical Cards & Sections):** Rendered in `#FFFFFF` with a 1px solid border in `#E3E8EE`. Ambient blur is minimal: `0 1px 2px rgba(22, 32, 43, 0.04)`.
- **Surface Level 2 (Floating Action Bars / Sticky Topbars / Dialogs):** `#FFFFFF` with a subtle elevation shadow: `0 4px 12px rgba(18, 69, 89, 0.08)` and bottom/top border `#E3E8EE`.
- **Interactive Focus/Active:** Elevation does not translate into dramatic physical lifting; instead, active items display a 2px focused ring in `#3FA7A0` or transition background to `#0B2C39`.

## Shapes

The geometric framework balances humanized clinical approachability with institutional precision:

- **Cards and Containers:** Standardized at 16px corner radius (`rounded-lg`), providing clear encapsulation of lab reports and clinical files without organic distortion.
- **Form Controls & Buttons:** Standardized at 8px to 12px radius, signaling interactability and precise targets.
- **Pill Badges:** Status chips and medical badges utilize a fully rounded pill format for distinct categorical recognition against rectangular cards.

## Components

### Buttons
- **Primary:** Background `#124559`, text `#FFFFFF`, height 48px, radius 10px. Pressed state `#0B2C39`. Disabled state background `#E3E8EE`, text `#4A5563`.
- **Secondary / Outlined:** Background transparent, border 1.5px solid `#124559`, text `#124559`, height 48px, radius 10px. Pressed state background `#F4F7F9`.
- **Destructive:** Border or background `#B3261E`, text `#FFFFFF` (filled) or `#B3261E` (outlined) for protocol termination or appointment cancellation.

### Input Fields
- **Container:** Minimum height 52px, surface `#FFFFFF`, border 1px solid `#E3E8EE`, radius 8px, padding 12px 16px.
- **Typography:** Value input `body-lg` in `#16202B`, floating or top label in `#4A5563` (`label-md`).
- **Focus State:** 2px border `#124559`.
- **Error State:** 2px border `#B3261E` with error hint in `label-sm` below field.

### Status Badges & Chips
- **Format:** Height 28px, horizontal padding 10px, radius 14px (pill).
- **Semantics:**
  - *Confirmed (`#124559`):* Background `#E7EFF2`, text `#124559`.
  - *Attended / Normal Range (`#2E7D5B`):* Background `#EAF4EF`, text `#2E7D5B`.
  - *Rescheduled / Pending (`#C98A0E`):* Background `#FAF4E7`, text `#966708`.
  - *Cancelled / Out of Range (`#B3261E`):* Background `#F9E9E8`, text `#B3261E`.
- Text is always accompanied by a 6px solid dot indicator or explicit status prefix.

### Patient & Appointment Cards
- Background `#FFFFFF`, border 1px solid `#E3E8EE`, radius 16px, padding 16px.
- **Internal Layout:** Top row holds patient initials badge and appointment time; center row holds patient full name and medical record number (HC); bottom row contains clinical procedure tag and status pill.

### Laboratory & Clinical Metric Strips
- Specialized horizontal card presenting: parameter name, observed value in `data-metric-md`, reference unit, and qualitative condition pill (`Dentro de rango` / `Fuera de rango`).

### Bottom Navigation Bar (Material 3 Adaptive)
- Height 64px + safe area padding. Background `#FFFFFF`, top border 1px solid `#E3E8EE`.
- **Destinations (4 Fixed Items):**
  1. **Inicio** (Clinical dashboard & daily overview)
  2. **Agenda** (Consultation calendar & procedures)
  3. **Pacientes** (Directory, historical cycles, lab findings)
  4. **Perfil** (Specialist credentials, shift protocols, clinical settings)
- **Active State:** Pill indicator `#124559` (with 10% opacity pill container `#E7EFF2`), icon and label in `#124559`.
- **Inactive State:** Icon and label in `#4A5563`.